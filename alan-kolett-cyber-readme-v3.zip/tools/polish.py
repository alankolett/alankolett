from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import re, zipfile
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'assets'
BG=(6,11,17); C=(55,241,211); Y=(225,255,104); P=(255,67,126); WHITE=(232,242,245); MUTED=(142,163,176)
def font(n,mono=False):
    for p in ([r'C:/Windows/Fonts/consola.ttf','DejaVuSansMono.ttf'] if mono else [r'C:/Windows/Fonts/bahnschrift.ttf','DejaVuSans.ttf']):
        try:return ImageFont.truetype(p,n)
        except OSError:pass
    return ImageFont.load_default(size=n)
def text(d,x,y,s,size,col=WHITE,mono=False):d.text((x,y),s,font=font(size,mono),fill=col)
frames=[]
labels=[('01 / INPUT','NETWORK TRAFFIC','PCAP / flow CSV'),('02 / ENCODE','STATE WINDOWS','Behavioral features'),('03 / MODEL','TEMPORAL MODEL','LSTM / two heads'),('04 / PREDICT','FUTURE STATES','Recursive rollout'),('05 / EXPLAIN','ATTRIBUTION','Gradient x input')]
for f in range(64):
    im=Image.new('RGB',(1280,300),BG);d=ImageDraw.Draw(im)
    d.line((25,1,1255,1,1279,25,1279,275,1255,299,1,299,1,25,25,1),fill=(36,62,72),width=2)
    text(d,28,22,'INSIDE SENTINEL',29)
    text(d,28,61,'From network traffic to an explainable forecast.',21,MUTED)
    text(d,971,30,'ARCHITECTURE / 01',15,C,True)
    for i,(tag,title,detail) in enumerate(labels):
        x=28+i*250
        d.polygon([(x,118),(x+210,118),(x+224,132),(x+224,223),(x,223)],fill=(13,27,35),outline=(39,77,87))
        d.line((x,118,x+57,118),fill=[C,C,Y,P,P][i],width=3)
        text(d,x+13,135,tag,14,[C,C,Y,P,P][i],True)
        text(d,x+13,166,title,19)
        text(d,x+13,195,detail,16,MUTED)
        if i<4:
            d.line((x+224,171,x+250,171),fill=(58,105,110),width=2)
            pos=x+224+(f%16)/16*26
            d.ellipse((pos-3,168,pos+3,174),fill=C)
    active=int(f/64*5)%5
    x=28+active*250
    d.line((x+2,224,x+222,224),fill=C,width=2)
    text(d,28,257,'SIH 2026 / PROBLEM 26153',14,Y,True)
    text(d,780,257,'CONCEPTUAL FLOW / OPEN THE REPOSITORY >',14,MUTED,True)
    frames.append(im)
frames[0].save(A/'sentinel-flow.png')
frames=[x.quantize(colors=96) for x in frames]
frames[0].save(A/'sentinel-flow.gif',save_all=True,append_images=frames[1:],duration=85,loop=0,optimize=True)

r=ROOT/'README.md';s=r.read_text(encoding='utf-8')
marker='<img src="./assets/section-work.png" width="100%" alt="01 — Selected builds" />'
flow='\n\n<a href="https://github.com/alankolett/Sentinel"><img src="./assets/sentinel-flow.gif" width="100%" alt="Inside Sentinel: PCAP or flow CSV becomes state windows, a two-head LSTM temporal model, future-state rollouts, and gradient-times-input attribution. Conceptual architecture, SIH 2026 problem 26153. Open repository." /></a>'
if './assets/sentinel-flow.gif' not in s:s=s.replace(marker,marker+flow)
anchor='<details>\n<summary><strong>Inside the builds — architecture, tradeoffs, and failure cases</strong></summary>'
plain='''**Start here:** [Sentinel](https://github.com/alankolett/Sentinel) for network forecasting · [TalentGraph](https://github.com/alankolett/TalentGraph) for hybrid retrieval · [MediQueue](https://github.com/alankolett/MediQueue) for real-time application design.

The repositories include prototypes and experiments. Expand the notes below for architecture, implementation choices, and current limits.

'''
if '**Start here:**' not in s:s=s.replace(anchor,plain+anchor)
r.write_text(s,encoding='utf-8')

# Update the artwork preview with the added architecture panel.
preview=Image.open(ROOT/'DESIGN-PREVIEW.png').convert('RGB')
# Original montage: hero 600, links 90, intro 250, heading 90, 12px gaps, scaled .75.
y=round((600+90+250+90+4*12)*.75)
panel=Image.open(A/'sentinel-flow.png').resize((960,225),Image.Resampling.LANCZOS)
out=Image.new('RGB',(960,preview.height+234),(13,17,23))
out.paste(preview.crop((0,0,960,y)),(0,0));out.paste(panel,(0,y));out.paste(preview.crop((0,y,960,preview.height)),(0,y+234))
out.save(ROOT/'DESIGN-PREVIEW.png')
print('Added animated architecture panel and native-text project navigation.')
