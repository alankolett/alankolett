"""Original procedural artwork. Python 3 + Pillow + NumPy; no remote assets."""
from pathlib import Path
import math, random, textwrap, json
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'assets'; A.mkdir(exist_ok=True)
C=(55,241,211); P=(255,67,126); Y=(225,255,104); WHITE=(232,242,245)
BG=(6,11,17); MUTED=(142,163,176)
def font(size,bold=False,mono=False):
    for name in ([r'C:/Windows/Fonts/consola.ttf','DejaVuSansMono.ttf'] if mono else [r'C:/Windows/Fonts/bahnschrift.ttf',r'C:/Windows/Fonts/arialbd.ttf' if bold else r'C:/Windows/Fonts/arial.ttf','DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf']):
        try:return ImageFont.truetype(name,size)
        except OSError:pass
    return ImageFont.load_default(size=size)
def txt(d,xy,s,size=20,fill=WHITE,bold=False,mono=False):
    d.text(xy,s,font=font(size,bold,mono),fill=fill)
def canvas(w,h):
    yy,xx=np.mgrid[0:h,0:w]; glow=np.exp(-(((xx-w*.76)/(w*.5))**2+((yy-h*.2)/(h*.9))**2)*3)
    arr=np.zeros((h,w,3),dtype=np.uint8)
    for k,b in enumerate(BG):arr[:,:,k]=b+glow*[3,13,18][k]
    return Image.fromarray(arr)
def frame(d,w,h,color=C):
    d.line((24,1,w-25,1,w-1,25,w-1,h-25,w-25,h-1,1,h-1,1,24,24,1),fill=(36,62,72),width=2)
    d.line((24,1,140,1),fill=color,width=3)
    d.line((w-120,h-2,w-25,h-2,w-2,h-25),fill=color,width=3)
def save(im,name):im.save(A/name)

# Hero: city silhouettes, extruded typography, rotating 3D octahedral reactor.
W,H=1280,600
base=canvas(W,H); d=ImageDraw.Draw(base); rng=random.Random(47)
for _ in range(130):
    x,y=rng.randrange(W),rng.randrange(460)
    d.point((x,y),fill=(31,66,77))
# City is decorative, not a contribution graph.
for layer in range(3):
    x=660
    while x<1280:
        bw=rng.randrange(22,65); bh=rng.randrange(45,165)+layer*12; y=460-bh
        col=(10+layer*3,22+layer*4,30+layer*6)
        d.rectangle((x,y,x+bw,500),fill=col)
        d.line((x,y,x+bw,y,x+bw,500),fill=(23,60+layer*10,68+layer*8))
        for wy in range(y+8,465,12):
            for wx in range(x+5,x+bw-4,9):
                if rng.random()>.58:d.rectangle((wx,wy,wx+2,wy+3),fill=(29,91,98) if layer%2 else (73,36,64))
        if rng.random()>.5:d.line((x+bw/2,y,x+bw/2,y-18),fill=(49,85,94))
        x+=bw+rng.randrange(5,16)
# Foreground dark scrim under the wordmark.
scrim=Image.new('RGBA',(W,H),(0,0,0,0)); sd=ImageDraw.Draw(scrim)
sd.polygon([(0,0),(630,0),(780,600),(0,600)],fill=(6,11,17,227));base=Image.alpha_composite(base.convert('RGBA'),scrim).convert('RGB');d=ImageDraw.Draw(base)
txt(d,(42,30),'AK / RESEARCH & DEVELOPMENT',16,C,mono=True)
txt(d,(1050,30),'PUNE / INDIA',16,MUTED,mono=True)
d.line((42,66,1238,66),fill=(43,64,73))
txt(d,(46,98),'SECURITY   /   INTELLIGENCE   /   SYSTEMS',18,Y,mono=True)
# Solid extrusion behind the name gives the wordmark depth.
for off in range(15,0,-1):
    txt(d,(37+off,135+off),'ALAN',132,(12,49,56),True)
    txt(d,(37+off,265+off),'KOLETT',132,(12,49,56),True)
txt(d,(37,135),'ALAN',132,WHITE,True)
txt(d,(37,265),'KOLETT',132,WHITE,True)
d.rectangle((43,414,100,418),fill=P)
txt(d,(118,402),'FOLLOW THE SIGNAL.',26,C,True)
txt(d,(43,455),'Network attacks. Retrieval. Real-time systems.',21,MUTED)
txt(d,(43,485),'I build the tools to understand them.',21,MUTED)
frame(d,W,H)
d.rectangle((25,548,1254,576),fill=(14,28,35))
txt(d,(43,552),'CYBERSECURITY STUDENT',14,C,mono=True)
txt(d,(431,552),'SOFTWARE INTERN',14,MUTED,mono=True)
txt(d,(845,552),'ALANKOLETT / ENGINEERING LOG',14,Y,mono=True)

def proj(x,y,z,a,cx=963,cy=284,scale=108):
    x,z=x*math.cos(a)+z*math.sin(a),-x*math.sin(a)+z*math.cos(a)
    y,z=y*math.cos(.27)-z*math.sin(.27),y*math.sin(.27)+z*math.cos(.27)
    q=5/(5+z)
    return (cx+x*scale*q,cy+y*scale*q),z
verts=[(0,-1.5,0),(1,0,0),(0,0,1),(-1,0,0),(0,0,-1),(0,1.5,0)]
faces=[(cap,i,1+i%4) for cap in [0,5] for i in range(1,5)]
frames=[]
for f in range(80):
    a=f/80*math.tau; im=base.copy(); dr=ImageDraw.Draw(im)
    layer=Image.new('RGB',(W,H)); ld=ImageDraw.Draw(layer)
    # Radial ground plane and conveyor-like perspective grid.
    for i in range(-6,8):ld.line((963+i*24,412,max(700,min(1250,963+i*150)),541),fill=(12,55,59),width=1)
    for i in range(8):
        yy=412+((i+f/80)/8)**2*129
        ld.line((730,yy,1240,yy),fill=(18,66,70),width=1)
    # Mechanical halo rings in projected 3D.
    for r,tilt,col in [(1.75,.38,C),(1.95,1.15,P),(2.1,-.8,(59,102,116))]:
        pts=[]
        for j in range(121):
            t=j/120*math.tau
            x,y,z=r*math.cos(t),r*math.sin(t)*math.cos(tilt),r*math.sin(t)*math.sin(tilt)
            p,_=proj(x,y,z,a*.0)
            pts.append(p)
        ld.line(pts,fill=tuple(int(v*.55) for v in col),width=1)
        t=a+tilt
        pp,_=proj(r*math.cos(t),r*math.sin(t)*math.cos(tilt),r*math.sin(t)*math.sin(tilt),0)
        ld.ellipse((pp[0]-4,pp[1]-4,pp[0]+4,pp[1]+4),fill=col)
    projected=[proj(*v,a) for v in verts]
    for face in sorted(faces,key=lambda face:-sum(projected[i][1] for i in face)):
        ps=[projected[i][0] for i in face]; depth=sum(projected[i][1] for i in face)/3
        ld.polygon(ps,fill=(8,25+int((2-depth)*7),33+int((2-depth)*9)))
        ld.line(ps+[ps[0]],fill=C if depth<0 else (33,121,130),width=2)
    # Inner core, offset rotation, and telemetry callouts.
    pp=[proj(v[0]*.42,v[1]*.42,v[2]*.42,-a*2) for v in verts]
    for face in faces:ld.line([pp[i][0] for i in face]+[pp[face[0]][0]],fill=P,width=2)
    ld.line((963,111,963,85,1065,85),fill=(49,123,129))
    ld.line((1082,308,1168,346,1216,346),fill=(49,123,129))
    ld.line((858,355,800,396,755,396),fill=(77,53,78))
    im=ImageChops.add(im,layer.filter(ImageFilter.GaussianBlur(5)).point(lambda p:int(p*.65)))
    im=ImageChops.add(im,layer)
    dr=ImageDraw.Draw(im)
    txt(dr,(1074,78),'CORE / AK',13,C,mono=True)
    txt(dr,(1097,355),'3D FIELD',13,MUTED,mono=True)
    # Slow sweep; no flashing.
    yy=115+f/80*330
    dr.line((749,yy,1219,yy),fill=(35,70,79))
    frames.append(im)
save(frames[12],'hero.png')
pal=frames[12].quantize(colors=192)
gf=[im.quantize(palette=pal,dither=Image.Dither.NONE) for im in frames]
gf[0].save(A/'hero.gif',save_all=True,append_images=gf[1:],duration=85,loop=0,optimize=True)

def strip(name,n,title,right):
    im=canvas(1280,90);d=ImageDraw.Draw(im)
    txt(d,(32,22),n,33,P,mono=True)
    txt(d,(105,22),title,32,WHITE,True)
    d.line((650,45,930,45),fill=(42,70,80))
    txt(d,(958,35),right,14,C,mono=True)
    save(im,name)
strip('section-work.png','01','SELECTED BUILDS','SOURCE / ARCHITECTURE')
strip('section-stack.png','02','WORKING TOOLKIT','TOOLS / METHODS')
strip('section-record.png','03','FIELD NOTES','EXPERIENCE / STUDY')
strip('section-credentials.png','04','SECURITY CREDENTIALS','NETWORK / LLM / OSINT')

projects=[
 ('sentinel','SENTINEL','NETWORK ATTACK FORECASTING',C,['Network-state sequences into an LSTM','world model, future-state rollouts, and','feature attribution for threat analysis.'],'Python / NumPy / FastAPI / Next.js','TRAFFIC > STATE > FORECAST'),
 ('talentgraph','TALENTGRAPH','HYBRID RETRIEVAL & RANKING',Y,['Dense search + BM25 + metadata filters.','Rank fusion, skill graphs, and cross-','encoder reranking build the shortlist.'],'Python / FastAPI / Qdrant / Docker','RETRIEVE > FUSE > RERANK'),
 ('finsense','FINSENSE AI','MULTI-AGENT BANKING',P,['Separate agents handle onboarding,','product guidance, and engagement,','with simulated banking integrations.'],'Python / FastAPI / React / RAG','ACQUIRE > ADOPT > ENGAGE'),
 ('asset-hunter','ASSET-HUNTER','DIGITAL-RIGHTS RECONNAISSANCE',C,['Suspected URLs become image + text','evidence. Multimodal analysis checks','context for signs of sports-media piracy.'],'React / Node.js / Gemini / Supabase','URL > EVIDENCE > ANALYSIS'),
 ('phishguard','PHISHGUARD PRO','PHISHING ANALYSIS',P,['URL, email, and QR-code scanning with','WHOIS, DNS, SSL, reputation checks,','and AI-assisted threat explanations.'],'FastAPI / Gemini / Supabase','SCAN > ENRICH > EXPLAIN'),
 ('mediqueue','MEDIQUEUE','REAL-TIME PATIENT FLOW',Y,['Socket.IO synchronizes receptionist,','patient, doctor, and public displays.','Wait estimates follow queue activity.'],'React / TypeScript / Socket.IO','TOKEN > EVENT > QUEUE')]

def circuit(d,x,y,col,kind):
    # Project-specific technical motifs on a shared isometric plinth.
    p=[(x-12,y+25),(x+55,y-5),(x+125,y+25),(x+55,y+57)]
    d.polygon(p,fill=(12,29,36),outline=(49,90,98))
    cx=x+55;cy=y-17
    if kind==0:
        for r in [18,35,52]:d.ellipse((cx-r,cy-r,cx+r,cy+r),outline=col if r==52 else (35,82,89))
        d.line((cx,cy,cx+37,cy-36),fill=col,width=2)
        for dx,dy in [(-18,-12),(22,19),(5,-34)]:d.ellipse((cx+dx-3,cy+dy-3,cx+dx+3,cy+dy+3),fill=col)
    elif kind==1:
        pts=[(cx-45,cy-25),(cx+42,cy-28),(cx,cy),(cx-39,cy+31),(cx+44,cy+32)]
        for a,b in [(0,2),(1,2),(2,3),(2,4),(0,1),(3,4)]:d.line((pts[a],pts[b]),fill=(98,119,61),width=2)
        for px,py in pts:d.ellipse((px-7,py-7,px+7,py+7),fill=(20,32,28),outline=col,width=2)
    elif kind==2:
        d.polygon([(cx-51,cy-20),(cx,cy-47),(cx+51,cy-20)],outline=col)
        for dx in [-35,0,35]:
            d.rectangle((cx+dx-6,cy-12,cx+dx+6,cy+31),outline=col,width=2)
        d.line((cx-54,cy+40,cx+54,cy+40),fill=col,width=3)
    elif kind==3:
        d.rectangle((cx-44,cy-42,cx+44,cy+29),outline=col,width=2)
        d.line((cx-35,cy+15,cx-12,cy-10,cx+8,cy+7,cx+24,cy-18,cx+37,cy+15),fill=col,width=2)
        d.ellipse((cx+5,cy+5,cx+46,cy+46),outline=P,width=3)
        d.line((cx+40,cy+42,cx+57,cy+59),fill=P,width=4)
    elif kind==4:
        d.polygon([(cx,cy-47),(cx+43,cy-29),(cx+35,cy+19),(cx,cy+47),(cx-35,cy+19),(cx-43,cy-29)],outline=col,width=2)
        d.line((cx,cy-21,cx,cy+9),fill=col,width=4);d.ellipse((cx-3,cy+20,cx+3,cy+26),fill=col)
    else:
        for dx in [-43,0,43]:
            d.ellipse((cx+dx-9,cy-33,cx+dx+9,cy-15),outline=col,width=2)
            d.line((cx+dx-14,cy+9,cx+dx-14,cy-3,cx+dx+14,cy-3,cx+dx+14,cy+9),fill=col,width=2)
        d.line((cx-60,cy+31,cx-28,cy+31,cx-14,cy+16,cx,cy+47,cx+13,cy+29,cx+60,cy+29),fill=col,width=2)

for i,(slug,title,sub,col,lines,stack,pipe) in enumerate(projects):
    im=canvas(640,370);d=ImageDraw.Draw(im);frame(d,640,370,col)
    txt(d,(28,22),f'PROJECT / 0{i+1}',14,col,mono=True)
    txt(d,(28,61),title,38,WHITE,True)
    txt(d,(29,112),sub,15,col,mono=True)
    circuit(d,477,89,col,i)
    for j,line in enumerate(lines):txt(d,(29,167+j*28),line,22,MUTED)
    d.line((29,268,609,268),fill=(36,62,72))
    txt(d,(29,282),stack,16,WHITE,mono=True)
    txt(d,(29,331),pipe,14,col,mono=True)
    txt(d,(548,326),'[ > ]',17,col,mono=True)
    save(im,f'{slug}.png')

# Panel typography is rasterized at 1280px so it survives GitHub font restrictions.
im=canvas(1280,250);d=ImageDraw.Draw(im);frame(d,1280,250)
txt(d,(36,28),'I FOLLOW THE FAILURE MODES.',36,WHITE,True)
for j,line in enumerate(['How does an intrusion develop across network states? Which retrieved result deserves',
                         'to rank first? What happens when four dashboards need the same queue state?',
                         'Those questions drive the projects here. I work across security, AI, and backend systems.']):
    txt(d,(37,91+j*33),line,24,MUTED)
txt(d,(37,208),'SSPU / B.TECH CSIT (CYBERSECURITY)     MESMERISE SOFT-TECH / SOFTWARE INTERN',16,C,mono=True)
save(im,'intro.png')

im=canvas(1280,330);d=ImageDraw.Draw(im);frame(d,1280,330,Y)
groups=[('SECURITY',['Burp Suite / Nmap / Wireshark','Ghidra / Metasploit / Kali Linux','Web testing / reconnaissance']),('AI & DATA',['Python / NumPy / FastAPI','RAG / BM25 / vector search','Qdrant / Ollama / reranking']),('APPLICATIONS',['TypeScript / React / Next.js','Node.js / Express / Socket.IO','PostgreSQL / Redis / Docker'])]
for i,(title,lines) in enumerate(groups):
    x=36+i*416
    txt(d,(x,33),title,22,[C,Y,P][i],True)
    for j,line in enumerate(lines):txt(d,(x,92+j*37),line,20,MUTED)
    if i<2:d.line((x+390,36,x+390,237),fill=(36,62,72))
d.line((36,246,1244,246),fill=(36,62,72))
txt(d,(36,274),'EXPLORING NEXT',16,Y,mono=True)
txt(d,(265,270),'Cloud security / Kubernetes / DevSecOps / system design',22,WHITE)
save(im,'stack.png')

im=canvas(1280,245);d=ImageDraw.Draw(im);frame(d,1280,245,P)
records=[('BUILD','Software Intern','Mesmerise Soft-Tech Private Limited'),('COMMUNITY','Cloud Security & Innovation Associate','AWS Student Builder Group at SSPU'),('STUDY','B.Tech CSIT / Cybersecurity','Symbiosis Skills & Professional University / 2025–2029')]
for i,(tag,title,detail) in enumerate(records):
    yy=24+i*72
    txt(d,(34,yy+5),tag,15,[C,Y,P][i],mono=True)
    txt(d,(214,yy),title,23,WHITE,True)
    txt(d,(214,yy+30),detail,19,MUTED)
save(im,'record.png')

im=canvas(1280,214);d=ImageDraw.Draw(im);frame(d,1280,214,Y)
for i,(abbr,issuer,date) in enumerate([('CNSP','The SecOps Group','JAN 2026'),('CLLMSP','Red Team Leaders','JUN 2026'),('CSEDP','The SecOps Group','JUN 2026'),('OSINT','CyberExam','JUN 2026')]):
    x=35+i*315
    txt(d,(x,29),abbr,40,WHITE,True)
    txt(d,(x,94),issuer,19,MUTED)
    txt(d,(x,143),date,16,[C,Y,P,C][i],mono=True)
    if i<3:d.line((x+282,30,x+282,180),fill=(36,62,72))
save(im,'credentials.png')

for slug,label,detail,col in [('github','GITHUB','EXPLORE THE SOURCE',C),('linkedin','LINKEDIN','EXPERIENCE & CREDENTIALS',Y),('email','EMAIL','START A CONVERSATION',P)]:
    im=canvas(420,90);d=ImageDraw.Draw(im);frame(d,420,90,col)
    txt(d,(24,14),label,24,col,True);txt(d,(24,52),detail,13,MUTED,mono=True)
    d.line((373,48,393,28,378,28),fill=col,width=2);d.line((393,28,393,43),fill=col,width=2)
    save(im,slug+'.png')

# Footer: an animated perspective packet tunnel.
out=[]
for f in range(40):
    im=canvas(1280,150);d=ImageDraw.Draw(im)
    for i in range(14):
        t=((i+f/40)/14)**2; rx=10+t*590; ry=5+t*115
        d.rectangle((970-rx,75-ry,970+rx,75+ry),outline=(12,int(28+55*t),int(40+45*t)))
    d.rectangle((0,0,650,150),fill=BG)
    txt(d,(34,28),'BUILD SOMETHING WORTH INSPECTING.',28,WHITE,True)
    txt(d,(35,84),'ALANKOLETT@GMAIL.COM  /  PUNE, INDIA',16,C,mono=True)
    frame(d,1280,150,P);out.append(im)
out[0].save(A/'footer.png')
out=[x.quantize(colors=96) for x in out]
out[0].save(A/'footer.gif',save_all=True,append_images=out[1:],duration=85,loop=0,optimize=True)

# Exact artwork montage, not a claim to be a GitHub-rendered screenshot.
parts=[Image.open(A/'hero.png')]
row=Image.new('RGB',(1280,90),BG)
for i,n in enumerate(['github','linkedin','email']):row.paste(Image.open(A/(n+'.png')),(i*430,0))
parts.extend([row,Image.open(A/'intro.png'),Image.open(A/'section-work.png')])
for n in range(0,6,2):
    row=Image.new('RGB',(1280,370),BG)
    for j in range(2):row.paste(Image.open(A/(projects[n+j][0]+'.png')),(j*640,0))
    parts.append(row)
for name in ['section-stack','stack','section-record','record','section-credentials','credentials','footer']:parts.append(Image.open(A/(name+'.png')))
preview=Image.new('RGB',(1280,sum(x.height for x in parts)+12*(len(parts)-1)),(13,17,23));y=0
for part in parts:preview.paste(part,(0,y));y+=part.height+12
preview.resize((960,round(preview.height*.75)),Image.Resampling.LANCZOS).save(ROOT/'DESIGN-PREVIEW.png')
print('Built',len(list(A.iterdir())),'assets; hero GIF',round((A/'hero.gif').stat().st_size/1024/1024,2),'MiB')
