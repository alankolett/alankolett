<div align="center">
<img src="./assets/hero.gif" width="100%" alt="Alan Kolett — cybersecurity, AI, and systems. A rotating 3D holographic core above a neon city, with an extruded wordmark." />
<a href="https://github.com/alankolett?tab=repositories"><img src="./assets/github.png" width="32%" alt="GitHub — explore my repositories" /></a>
<a href="https://www.linkedin.com/in/alan-kolett-00019325b/"><img src="./assets/linkedin.png" width="32%" alt="LinkedIn — experience and credentials" /></a>
<a href="mailto:alankolett@gmail.com"><img src="./assets/email.png" width="32%" alt="Email — start a conversation" /></a>
</div>

<br />

<img src="./assets/intro.png" width="100%" alt="I follow the failure modes. How does an intrusion develop across network states? Which retrieved result deserves to rank first? What happens when four dashboards need the same queue state? Those questions drive my projects in security, AI, and backend systems. B.Tech CSIT cybersecurity student at SSPU; software intern at Mesmerise Soft-Tech." />

<img src="./assets/section-work.png" width="100%" alt="01 — Selected builds" />

<a href="https://github.com/alankolett/Sentinel"><img src="./assets/sentinel-flow.gif" width="100%" alt="Inside Sentinel: PCAP or flow CSV becomes state windows, a two-head LSTM temporal model, future-state rollouts, and gradient-times-input attribution. Conceptual architecture, SIH 2026 problem 26153. Open repository." /></a>

<p align="center">
<a href="https://github.com/alankolett/Sentinel"><img src="./assets/sentinel.png" width="49%" align="top" alt="Sentinel: network attack forecasting with an LSTM world model, future-state rollouts, and feature attribution. Python, NumPy, FastAPI, Next.js. Open repository." /></a>
<a href="https://github.com/alankolett/TalentGraph"><img src="./assets/talentgraph.png" width="49%" align="top" alt="TalentGraph: dense search, BM25, metadata filters, rank fusion, skill graphs, and cross-encoder reranking. Python, FastAPI, Qdrant, Docker. Open repository." /></a>
</p>
<p align="center">
<a href="https://github.com/alankolett/FinSense-AI"><img src="./assets/finsense.png" width="49%" align="top" alt="FinSense AI: multi-agent banking assistant for onboarding, product guidance, and customer engagement, using simulated banking integrations. Python, FastAPI, React, RAG. Open repository." /></a>
<a href="https://github.com/alankolett/Asset-Hunter"><img src="./assets/asset-hunter.png" width="49%" align="top" alt="Asset-Hunter: digital-rights reconnaissance using scraped images and contextual text to analyze suspected sports-media piracy. React, Node.js, Gemini, Supabase. Open repository." /></a>
</p>
<p align="center">
<a href="https://github.com/alankolett/PhishGuard-Pro"><img src="./assets/phishguard.png" width="49%" align="top" alt="PhishGuard Pro: URL, email, and QR-code analysis with WHOIS, DNS, SSL, reputation checks, and AI threat explanations. FastAPI, Gemini, Supabase. Open repository." /></a>
<a href="https://github.com/alankolett/MediQueue"><img src="./assets/mediqueue.png" width="49%" align="top" alt="MediQueue: Socket.IO synchronizes receptionist, patient, doctor, and public displays; wait estimates follow queue activity. React, TypeScript, Socket.IO. Open repository." /></a>
</p>

**Start here:** [Sentinel](https://github.com/alankolett/Sentinel) for network forecasting · [TalentGraph](https://github.com/alankolett/TalentGraph) for hybrid retrieval · [MediQueue](https://github.com/alankolett/MediQueue) for real-time application design.

The repositories include prototypes and experiments. Expand the notes below for architecture, implementation choices, and current limits.

<details>
<summary><strong>Inside the builds — architecture, tradeoffs, and failure cases</strong></summary>

### Sentinel / Forecasting attack progression

[Sentinel](https://github.com/alankolett/Sentinel) models sequences of network states and rolls predicted states forward to estimate how an intrusion could develop. The repository documents a NumPy LSTM implementation with a next-state prediction head, an attack-stage classification head, and gradient × input attribution.

`PCAP / flow CSV → feature windows → LSTM → future-state rollout → attribution`

The interesting failure case: near-constant training features could make normal, unfamiliar traffic look extreme after standardization. The documented fixes include a standard-deviation floor, input clipping, diverse safe-traffic augmentation, and regression coverage. That is the part of security ML I want to understand: how a model behaves when the data stops looking familiar.

SIH 2026 prototype addressing problem statement 26153. See the repository for its reported benchmark setup and limitations.

### TalentGraph / Retrieval is only the first stage

[TalentGraph](https://github.com/alankolett/TalentGraph) combines dense similarity, BM25 keyword matching, and metadata filters using Reciprocal Rank Fusion. Skill-graph distance and other candidate features feed a scoring stage; a cross-encoder reranks the shortlist.

`Validate → parse → skill graph + embeddings → hybrid retrieval → score → rerank → evaluate`

The repository separates lightweight offline backends from real model integrations. Hashing embeddings and mock rerankers support local verification; sentence-transformer backends are separate options. Evaluation is an explicit pipeline stage rather than an assumption that a plausible ranking is a good one.

### FinSense AI / Banking workflows with separate agents

[FinSense AI](https://github.com/alankolett/FinSense-AI) divides work between **Acquire**, **Adopt**, and **Engage** agents: onboarding and KYC, product guidance, and customer support or alerts. A FastAPI router connects the agents and their tools to a React banker dashboard.

The documented architecture includes product documents for retrieval, customer memory, and **simulated CBS / CKYC / UPI APIs**. It is a prototype; the banking integrations are not a claim of a live bank deployment.

### Asset-Hunter / Context around the image matters

[Asset-Hunter](https://github.com/alankolett/Asset-Hunter) extracts images and surrounding text from suspected URLs, analyzes them with Gemini, and stores threat records in Supabase. Its focus is suspected unauthorized sports-media distribution. Visual cues and language are considered together, with results exposed through a React dashboard.

### PhishGuard Pro / Enrichment before explanation

[PhishGuard Pro](https://github.com/alankolett/PhishGuard-Pro) documents URL, email, and QR-code scanning; WHOIS, DNS, and SSL analysis; VirusTotal and Google Safe Browsing integrations; Gemini explanations; and PDF reports. FastAPI provides the backend, with Supabase for authentication and storage.

### MediQueue / One queue, four views

[MediQueue](https://github.com/alankolett/MediQueue) uses Socket.IO to distribute token and queue updates to receptionist, patient, doctor, and public-display interfaces. Queue position and consultation duration inform wait estimates.

The project is a real-time prototype. Persistent PostgreSQL storage, patient notifications, and formal clinical usability testing are described as next steps in the [project write-up](https://wooble.org/in/alankoletta879f/projects/890acd02-b313-4cd9-b7bd-8ae4f02d8ce4).

</details>

<details>
<summary><strong>More repositories & earlier experiments</strong></summary>

[IRIS 3.0](https://github.com/alankolett/Iris-3.0) · [Free LLM API](https://github.com/alankolett/freellmapi) · [PayPulse](https://github.com/alankolett/PayPulse) · [Permit AI](https://github.com/alankolett/permit_ai) · [Perceptron](https://github.com/alankolett/perceptron-main) · [IRIS AI](https://github.com/alankolett/Iris-ai)

</details>

<br />
<img src="./assets/section-stack.png" width="100%" alt="02 — Working toolkit" />
<img src="./assets/stack.png" width="100%" alt="Security: Burp Suite, Nmap, Wireshark, Ghidra, Metasploit, Kali Linux, web testing and reconnaissance. AI and data: Python, NumPy, FastAPI, RAG, BM25, vector search, Qdrant, Ollama and reranking. Applications: TypeScript, React, Next.js, Node.js, Express, Socket.IO, PostgreSQL, Redis and Docker. Exploring cloud security, Kubernetes, DevSecOps and system design." />

<details>
<summary><strong>Languages and additional tools</strong></summary>

Python · TypeScript · JavaScript · C · C++ · Java · Bash · HTML · CSS  
MongoDB · MySQL · PostgreSQL · Redis · Tailwind CSS · Linux · Git

</details>

<br />
<img src="./assets/section-record.png" width="100%" alt="03 — Field notes: experience and study" />
<img src="./assets/record.png" width="100%" alt="Software Intern at Mesmerise Soft-Tech Private Limited. Cloud Security and Innovation Associate at AWS Student Builder Group at SSPU. B.Tech CSIT cybersecurity at Symbiosis Skills and Professional University, 2025–2029." />

**Team Cyber Synergists — 2nd place in Round 2, Gönn.dir–Träger × SSPU Hackathon 2026.** Database contributor; the team advanced to the Grand Finale. [Team announcement](https://in.linkedin.com/in/jay-sonar-573637275)

<br />
<img src="./assets/section-credentials.png" width="100%" alt="04 — Security credentials" />
<a href="https://www.linkedin.com/in/alan-kolett-00019325b/"><img src="./assets/credentials.png" width="100%" alt="CNSP — The SecOps Group, January 2026. CLLMSP — Red Team Leaders, June 2026. CSEDP — The SecOps Group, June 2026. OSINT Fundamentals — CyberExam, June 2026. See LinkedIn for credential details." /></a>

<details>
<summary><strong>Full credential names & additional learning</strong></summary>

| Credential | Issuer |
| :--- | :--- |
| Certified Network Security Practitioner (CNSP) | The SecOps Group |
| Certified LLM Security Professional (CLLMSP) | Red Team Leaders |
| Certified Social Engineering Defense Practitioner (CSEDP) | The SecOps Group |
| OSINT Fundamentals | CyberExam |
| Claude 101 | Anthropic |
| Cybersecurity | Tech Mahindra |
| Data Operations Using MATLAB | MATLAB@UCL |
| Generative AI | NxtWave |
| Introduction to Cybersecurity | Cisco |
| Security Command Center Fundamentals | Google Cloud Skills Boost |

[View credentials on LinkedIn](https://www.linkedin.com/in/alan-kolett-00019325b/)

</details>

<!-- CONTRIBUTIONS:START -->
<!-- The optional workflow inserts your real 3D contribution calendar here after its first successful run. -->
<!-- CONTRIBUTIONS:END -->

<br />
<a href="mailto:alankolett@gmail.com"><img src="./assets/footer.gif" width="100%" alt="Build something worth inspecting. Contact alankolett@gmail.com. Pune, India." /></a>

<p align="center"><sub>Security tools, retrieval systems, or backend engineering — <a href="mailto:alankolett@gmail.com">let's talk.</a></sub></p>
