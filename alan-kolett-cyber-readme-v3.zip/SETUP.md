# Install the new profile

Copy `README.md` and the entire `assets/` folder into the root of `alankolett/alankolett` and commit them together. Nothing is published by this download.

The design works immediately: all three animations are bundled GIFs, and the visual panels are bundled PNGs. There are no remote image widgets. Every project card links to its repository; contact buttons work as ordinary Markdown/HTML links. Expandable sections contain the technical writing as selectable text.

`DESIGN-PREVIEW.png` is an artwork montage, not a screenshot of GitHub's renderer. GitHub adds its own spacing and outer chrome. At narrow mobile widths, the paired project cards become smaller; their complete descriptions remain in alt text and in the expandable architecture section.

## Optional: real 3D contributions

1. Copy `optional/profile-3d.yml` to `.github/workflows/profile-3d.yml` in the profile repository.
2. Commit the file, then open **Actions → Update 3D contribution calendar → Run workflow**.
3. After a successful run, the workflow commits the generated calendar and inserts its image into the README. Until that happens, no broken image appears.

The workflow uses the built-in `GITHUB_TOKEN` with `contents: write`; no personal token is required for the standard public-data setup. Repository rules must permit the workflow to push to the default branch. It also schedules a daily update at 00:53 India time (19:23 UTC). It has been checked locally but has not been executed in your GitHub account.

The hero city is decorative artwork. Only the optional generated contribution calendar represents GitHub activity.

## Edit or reduce motion

- Change `hero.gif` to `hero.png` , `sentinel-flow.gif` to `sentinel-flow.png`, and `footer.gif` to `footer.png` for a static profile.
- Edit `tools/build.py` and run it to regenerate the artwork. Requirements: Python 3, Pillow, NumPy. `python -m pip install Pillow numpy` then `python tools/build.py` and `python tools/polish.py`.
- Text in the visual panels is generated from the script. Keep matching README alt text in sync when editing it.
- GitHub's motion preference may pause animated GIFs; all first frames remain readable. See [GitHub accessibility settings](https://docs.github.com/en/account-and-profile/how-tos/account-settings/managing-accessibility-settings).

## Included

- `README.md`: the profile to publish.
- `assets/`: all original local artwork, including 3D hero and tunnel animations.
- `tools/build.py`: reproducible artwork source.
- `optional/profile-3d.yml`: optional daily contribution renderer.
- `RESEARCH-AND-AUDIT.md`: design references, evidence, and corrections.
- `DESIGN-PREVIEW.png`: static artwork preview.

The artwork is original procedural geometry. It does not reuse another developer's banner, portrait, branding, or assets.

