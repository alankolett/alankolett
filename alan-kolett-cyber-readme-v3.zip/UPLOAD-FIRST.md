# Upload in about two minutes

1. Download and extract `alan-kolett-cyber-readme-v3.zip` on your computer.
2. Open https://github.com/alankolett/alankolett and sign in as `alankolett`.
3. On the repository's **Code** page, choose **Add file → Upload files**.
4. From the extracted ZIP, drag **README.md** and the entire **assets** folder into the upload area together. Upload the folder itself so the `assets/` path is preserved. Do not upload the ZIP or the enclosing package folder.
5. Check that the upload list shows `README.md`, `assets/hero.gif`, and the other `assets/...` files.
6. Enter a commit message such as `Refresh profile README`. Commit to the default branch if GitHub allows it. If GitHub requires a new branch, choose **Propose changes**, create the pull request, and merge it.
7. Open https://github.com/alankolett to view your profile. Refresh once if images are still loading.

Uploading `README.md` at the same path updates the existing README. Your Git history retains the previous version. Uploading the assets does not require deleting unrelated files.

Your repository should look like this:

```text
alankolett/
├── README.md
└── assets/
    ├── hero.gif
    ├── sentinel-flow.gif
    ├── footer.gif
    └── ...remaining supplied images
```

The repository must stay public, be named `alankolett`, and contain `README.md` at the root for the README to appear on your profile.

## If an image is broken

Check that the image is inside `assets/` at the repository root, not inside an extra `cyber-readme-v3/` folder. Names and capitalization must match. If images appear on the repository page but not immediately on your profile, refresh after a short wait.

## Optional contribution calendar

All visual animations work after the basic upload. You do not need Actions for them. For a calendar based on real GitHub contributions, follow `SETUP.md` to install the optional workflow separately.

## Editing later

Edit ordinary README text in GitHub's editor. The visual panel text is part of the image files; edit the included Python generator to change that artwork. Run `python tools/build.py` followed by `python tools/polish.py` to rebuild the complete design. Those scripts require Pillow and NumPy. You do not need Python just to upload the supplied files.

Official references: [Uploading files](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository) · [Profile README requirements](https://docs.github.com/github/setting-up-and-managing-your-github-profile/customizing-your-profile/managing-your-profile-readme)
